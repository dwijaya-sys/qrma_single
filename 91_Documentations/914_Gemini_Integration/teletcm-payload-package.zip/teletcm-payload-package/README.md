# TeleTCM Payload Package

This package contains a copy-paste JSON Schema and PostgreSQL SQL model for a stable TeleTCM scan payload.

## Files

- `teletcm-scan-payload.schema.json` — canonical payload contract for API handoff.
- `teletcm-sql-model.sql` — PostgreSQL table, enums, indexes, trigger, and export view.

## Design choices

- QRMA-only ingestion works now.
- GDV fields are retained now but nullable.
- Missing GDV should be `null`, `{}`, or omitted inside nested raw GDV content — never faked as numeric zero.
- `flagged_gdv_params`, `energy_total`, `energy_reserve`, `lifestyle_scores`, and `chakra_alignment` remain nullable until GDV data is available.
- A SQL view (`teletcm_scan_payload_v1`) exports rows back into the JSON payload shape expected by another AI system.

## Recommended ingestion rules

1. If only QRMA is present, set:
   - `instrument.mode = "QRMA"`
   - `instrument.qrma_present = true`
   - `instrument.gdv_present = false`
   - `rawdata.gdv = null`
2. Keep GDV-derived computed outputs as `null` until real GDV data arrives.
3. Do not interpret missing GDV as normal GDV.
4. When GDV arrives later, enrich the same record or create a new versioned session and rerun flagging, correlations, clustering, and pattern assignment.
