-- TeleTCM PostgreSQL SQL model
-- Purpose: stable QRMA/GDV scan storage with nullable GDV fields retained from day one.
-- Notes:
-- 1) QRMA-only sessions are allowed.
-- 2) GDV columns and JSON blocks remain present but nullable.
-- 3) Use NULL for missing GDV values, never numeric zero placeholders.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'instrument_mode') THEN
    CREATE TYPE instrument_mode AS ENUM ('QRMA', 'GDV', 'both');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'cluster_code') THEN
    CREATE TYPE cluster_code AS ENUM ('A', 'B', 'C', 'AB', 'AC', 'BC', 'ABC', 'none');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'severity_level') THEN
    CREATE TYPE severity_level AS ENUM ('none', 'mild', 'moderate', 'severe');
  END IF;
END$$;

CREATE TABLE IF NOT EXISTS teletcm_scans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  client_id VARCHAR(64) NOT NULL,
  client_name TEXT NOT NULL,
  client_age INTEGER,
  client_gender VARCHAR(32),

  scan_id VARCHAR(64) NOT NULL UNIQUE,
  scan_date TIMESTAMPTZ NOT NULL,
  source VARCHAR(32) NOT NULL CHECK (source IN ('dashboard', 'import', 'api')),
  language_code VARCHAR(8) NOT NULL CHECK (language_code IN ('en', 'id')),

  instrument instrument_mode NOT NULL,
  qrma_present BOOLEAN NOT NULL DEFAULT TRUE,
  gdv_present BOOLEAN NOT NULL DEFAULT FALSE,

  raw_qrma JSONB NOT NULL DEFAULT '{}'::jsonb,
  raw_gdv JSONB,

  hrv_present BOOLEAN NOT NULL DEFAULT FALSE,
  hrv_ali_band VARCHAR(32),
  hrv_rmssd NUMERIC(10,3),
  hrv_mean_hr NUMERIC(10,3),
  hrv_quality VARCHAR(64),
  hrv_recovery_state VARCHAR(64),

  flagged_qrma_params JSONB NOT NULL DEFAULT '[]'::jsonb,
  flagged_gdv_params JSONB,
  confirmed_correlations JSONB NOT NULL DEFAULT '[]'::jsonb,

  cluster_score_a NUMERIC(5,2) CHECK (cluster_score_a BETWEEN 0 AND 100),
  cluster_score_b NUMERIC(5,2) CHECK (cluster_score_b BETWEEN 0 AND 100),
  cluster_score_c NUMERIC(5,2) CHECK (cluster_score_c BETWEEN 0 AND 100),

  cluster_severity_a severity_level NOT NULL DEFAULT 'none',
  cluster_severity_b severity_level NOT NULL DEFAULT 'none',
  cluster_severity_c severity_level NOT NULL DEFAULT 'none',

  primary_cluster cluster_code,
  active_clusters JSONB NOT NULL DEFAULT '[]'::jsonb,
  tcm_pattern_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
  primary_tcm_pattern VARCHAR(64),

  stress_index NUMERIC(10,3),
  energy_total NUMERIC(10,3),
  energy_reserve NUMERIC(10,3),
  lifestyle_scores JSONB,
  chakra_alignment JSONB,

  ai_red_flags JSONB NOT NULL DEFAULT '[]'::jsonb,
  practitioner_note TEXT,
  requested_output VARCHAR(64) CHECK (requested_output IN ('synthesis', 'patient_summary', 'progress_narrative', 'copilot')),

  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT gdv_presence_consistency CHECK (
    (gdv_present = FALSE AND instrument IN ('QRMA', 'both')) OR
    (gdv_present = TRUE AND instrument IN ('GDV', 'both')) OR
    (gdv_present = FALSE AND instrument = 'GDV')
  ),
  CONSTRAINT raw_qrma_required_when_present CHECK (
    (qrma_present = TRUE AND raw_qrma IS NOT NULL) OR
    (qrma_present = FALSE)
  ),
  CONSTRAINT raw_gdv_nullable_when_absent CHECK (
    gdv_present = TRUE OR raw_gdv IS NULL OR raw_gdv = '{}'::jsonb
  )
);

CREATE INDEX IF NOT EXISTS idx_teletcm_scans_client_id ON teletcm_scans (client_id);
CREATE INDEX IF NOT EXISTS idx_teletcm_scans_scan_date ON teletcm_scans (scan_date DESC);
CREATE INDEX IF NOT EXISTS idx_teletcm_scans_instrument ON teletcm_scans (instrument);
CREATE INDEX IF NOT EXISTS idx_teletcm_scans_raw_qrma_gin ON teletcm_scans USING GIN (raw_qrma);
CREATE INDEX IF NOT EXISTS idx_teletcm_scans_raw_gdv_gin ON teletcm_scans USING GIN (raw_gdv);
CREATE INDEX IF NOT EXISTS idx_teletcm_scans_flagged_qrma_gin ON teletcm_scans USING GIN (flagged_qrma_params);
CREATE INDEX IF NOT EXISTS idx_teletcm_scans_flagged_gdv_gin ON teletcm_scans USING GIN (flagged_gdv_params);

-- Optional view for downstream AI systems expecting one object-shaped export.
CREATE OR REPLACE VIEW teletcm_scan_payload_v1 AS
SELECT jsonb_build_object(
  'client', jsonb_build_object(
    'client_id', client_id,
    'name', client_name,
    'age', client_age,
    'gender', client_gender
  ),
  'session', jsonb_build_object(
    'scan_id', scan_id,
    'scan_date', scan_date,
    'source', source,
    'language', language_code
  ),
  'instrument', jsonb_build_object(
    'mode', instrument,
    'qrma_present', qrma_present,
    'gdv_present', gdv_present
  ),
  'rawdata', jsonb_build_object(
    'qrma', raw_qrma,
    'gdv', raw_gdv
  ),
  'hrv', jsonb_build_object(
    'present', hrv_present,
    'ali_band', hrv_ali_band,
    'rmssd', hrv_rmssd,
    'mean_hr', hrv_mean_hr,
    'quality', hrv_quality,
    'recovery_state', hrv_recovery_state
  ),
  'computed', jsonb_build_object(
    'flagged_qrma_params', flagged_qrma_params,
    'flagged_gdv_params', flagged_gdv_params,
    'confirmed_correlations', confirmed_correlations,
    'cluster_scores', jsonb_build_object(
      'A', cluster_score_a,
      'B', cluster_score_b,
      'C', cluster_score_c
    ),
    'cluster_severity', jsonb_build_object(
      'A', cluster_severity_a,
      'B', cluster_severity_b,
      'C', cluster_severity_c
    ),
    'primary_cluster', primary_cluster,
    'active_clusters', active_clusters,
    'tcm_pattern_ids', tcm_pattern_ids,
    'primary_tcm_pattern', primary_tcm_pattern,
    'stress_index', stress_index,
    'energy_total', energy_total,
    'energy_reserve', energy_reserve,
    'lifestyle_scores', lifestyle_scores,
    'chakra_alignment', chakra_alignment
  ),
  'ai_context', jsonb_build_object(
    'red_flags', ai_red_flags,
    'practitioner_note', practitioner_note,
    'requested_output', requested_output
  )
) AS payload
FROM teletcm_scans;

-- Trigger to keep updated_at current.
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_teletcm_scans_updated_at ON teletcm_scans;
CREATE TRIGGER trg_teletcm_scans_updated_at
BEFORE UPDATE ON teletcm_scans
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
