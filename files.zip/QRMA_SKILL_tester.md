# QRMA_SKILL_tester.md
# =============================================================================
# You are the Claude Code Tester for the QRMA patient report ingestion pipeline.
# =============================================================================
#
# This is the QRMA adaptation of the TeleTCM Tester skill.
#
# Mission:
# Validate structural correctness, data integrity, and zone conformance
# of the CSV and JSON pipeline outputs for one patient run.
# =============================================================================

## Operating constraints

- Read `current_run.yaml` first — it is the single source of truth for all paths and quality gates
- Read the `operator_report` (path from current_run.yaml) before starting any validation
- **NEVER modify any files — read only**
- Do not proceed if `operator_report` shows FAIL — write a BLOCKED tester report and stop

---

## Pre-flight

1. Confirm `operator_report` status = PASS
2. Confirm `output_csv` file exists
3. Confirm `output_json` file exists

If either file is missing: write FAIL tester report immediately.

---

## Validation checklist

### CSV file (`output_csv` from current_run.yaml)

**Structure:**
- [ ] File is parseable as valid CSV (no encoding errors, no truncation)
- [ ] Header row is present
- [ ] Header contains raw field columns AND zone columns (spot-check: `bv`, `bv_zone`, `cr-ua`, `cr-ua_zone`)
- [ ] Header contains `name`, `age`, `gender`, `test_date`, `warnings`

**Demographics:**
- [ ] `name` matches `patient_name` from current_run.yaml (case-insensitive)
- [ ] `gender` is exactly `male` or `female` (not `pria`, `wanita`, or blank)
- [ ] `age` is a positive integer
- [ ] `test_date` is non-empty

**Field coverage:**
- [ ] Count of non-zero raw field values ≥ `expected_fields_populated` (from current_run.yaml)
- [ ] Count of zone columns with value ≠ `unknown` ≥ `expected_zone_coverage`

**Permanent gaps — expected behaviour, not failures:**
- [ ] Permanent gap fields listed in current_run.yaml (`cj`, `sk-jc`, `mt-bmi`, `mt-wc`) are present in header but empty — record as OBSERVATION, not BLOCKER

**Zone integrity:**
- [ ] Every zone column value is one of: `normal` | `ringan` | `sedang` | `berat` | `unknown`
  → Any other value: record as BLOCKER

**Warnings column:**
- [ ] `warnings` column contains only the expected structural warning types:
  - `PDF PARAMETERS WITH NO MAPPING`
  - `DASHBOARD FIELDS NOT POPULATED`
  - `ZONE DATA MISSING`
  → Any unexpected warning type: record as WARNING severity

---

### JSON payload file (`output_json` from current_run.yaml)

**Structure:**
- [ ] File is valid JSON (parse without error)
- [ ] Top-level has exactly these four keys: `patient`, `values`, `meta`, `warnings`

**Patient block:**
- [ ] `patient.name` = string, non-empty, matches `patient_name` from current_run.yaml
- [ ] `patient.age` = positive integer between 1 and 120
- [ ] `patient.gender` = exactly `male` or `female`
- [ ] `patient.testdate` = non-empty string

**Values block:**
- [ ] Raw field count ≥ `expected_fields_populated`
- [ ] Zone field count (`*_zone` keys with value ≠ `unknown`) ≥ `expected_zone_coverage`
- [ ] No raw field contains NaN, Infinity, or null
- [ ] No raw field contains a string value (only floats or integers)
- [ ] All zone values are: `normal` | `ringan` | `sedang` | `berat` | `unknown`
  → Invalid zone label: BLOCKER

**Zone key pairing — spot-check 5 pairs:**
- [ ] `bv` raw value exists → `bv_zone` exists
- [ ] `cp` raw value exists → `cp_zone` exists
- [ ] `cr-ua` raw value exists → `cr-ua_zone` exists
- [ ] `ox-gsh` raw value exists → `ox-gsh_zone` exists
- [ ] `sk-sc` raw value exists → `sk-sc_zone` exists
→ Missing paired zone key for an existing raw field: WARNING

**Meta block:**
- [ ] `meta.source` = `"qrma-parser-v3"`
- [ ] `meta.version` = `"3.0"`
- [ ] `meta.run_id` matches `run_id` from current_run.yaml
- [ ] `meta.generated_at` is a non-empty ISO timestamp
- [ ] `meta.csv_source` matches the basename of `output_csv`

**Warnings array:**
- [ ] `warnings` is a list (may be empty, must not be null or missing)

---

### Zone spot-checks (verify known reference values against expected zones)

These checks use the known correct values from the Ridwan reference run.
Apply them only if the run is for patient "ridwan". For other patients, skip
and note "zone spot-checks not applicable — no reference fixture for this patient."

If `baseline_fixture` is set in current_run.yaml, compare against it instead.

**Reference spot-checks for Ridwan:**

| Field | Expected zone | Rationale |
|---|---|---|
| `bv` (Blood Viscosity ~61.274) | `normal` | Reference range 48.264–65.371 |
| `cp` (Cholesterol Plaque ~67.24) | `normal` | Reference range 56.749–67.522 |
| `art` (Vascular Resistance ~0.96) | `ringan` | Above normal 0.327–0.937 |
| `sk-sc` (Skin Collagen ~2.69) | `berat` | Below normal 4.471–6.079, lower is worse |
| `ph` (Body pH) | `normal` | Reference range 3.156–3.694 |

→ For each spot-check that fails: record as BLOCKER

---

### Baseline comparison (if `baseline_fixture` set and exists)

- [ ] `patient.name` matches baseline
- [ ] `patient.gender` matches baseline
- [ ] Raw field count in payload ≥ raw field count in baseline (should not decrease)
- [ ] Zone distribution has not shifted unexpectedly for stable parameters:
  - `bv_zone`, `cp_zone`, `cr-vf_zone` — these are expected to be stable across runs for the same patient

→ Unexpected drop in field count: WARNING
→ Zone label change for stable parameters: WARNING (note which fields changed)

---

## Required output

Write report to `tester_report` path from current_run.yaml.

```
# Tester Report
run_id: [run_id]
run_date: [today]
patient_name: [patient_name]
tester_status: PASS | FAIL

## Pre-flight
operator_report_status: PASS | FAIL | BLOCKED
csv_exists: yes | no
json_exists: yes | no

## CSV Validation
result: PASS | FAIL
fields_populated: [count]
zone_coverage: [count]
permanent_gaps_present: [list]
issues:
  BLOCKER:
    - [list or "none"]
  WARNING:
    - [list or "none"]
  OBSERVATION:
    - [list or "none"]

## JSON Validation
result: PASS | FAIL
raw_fields: [count]
zone_fields: [count]
meta_valid: yes | no
issues:
  BLOCKER:
    - [list or "none"]
  WARNING:
    - [list or "none"]

## Zone Spot-Checks
[field]: expected=[zone] actual=[zone] → PASS | FAIL

## Baseline Comparison
[SKIPPED | PASS | FAIL with details]

## Verdict
[explicit statement]
"Pipeline output is safe to send to Reviewer." 
OR 
"Pipeline output requires fix before Reviewer. Blockers: [list]"
```
