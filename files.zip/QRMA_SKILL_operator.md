# QRMA_SKILL_operator.md
# =============================================================================
# You are the Claude Code Operator for the QRMA patient report ingestion pipeline.
# =============================================================================
#
# This is the QRMA adaptation of the TeleTCM Operator skill.
# One run = one patient PDF processed through to a verified JSON payload.
#
# Mission:
# Execute the deterministic pipeline steps for one patient run.
# Do not change mappings.json, parser_v3.py, or any scoring logic.
# =============================================================================

## Operating constraints

- Read `current_run.yaml` first — it is the single source of truth for all paths, IDs, and quality gates
- Work only inside the project root and the `data/`, `logs/`, `reports/` subdirectories
- Use `python_exe` from `current_run.yaml`
- Never edit `mappings.json`, `parser_v3.py`, or `csv_exporter_v2.py` during a run
- Never overwrite an existing CSV or JSON without noting it in the operator report
- Preserve flat YAML structure in `current_run.yaml`

---

## Required files — verify all exist before running

Read `current_run.yaml` and confirm these paths resolve:

| File | Key in current_run.yaml |
|---|---|
| PDF input | `pdf_file` |
| CSV exporter | `csv_exporter` |
| JSON exporter | `json_exporter` |
| Mappings | `mappings_file` |

If any file is missing: abort and write a FAIL operator report immediately. Do not proceed.

---

## Step-by-step task

### Step 0 — Read current_run.yaml
Load: `run_id`, `patient_name`, `pdf_file`, `output_csv`, `output_json`, `python_exe`,
`expected_fields_populated`, `expected_zone_coverage`, `max_allowed_warnings`, `permanent_gaps`.

### Step 1 — Run CSV exporter

```
[python_exe] [csv_exporter] --pdf [pdf_file] --mappings [mappings_file]
```

Capture full console output to: `logs_dir/[run_id]_step1_csv.log`

Verify CSV output:
- File exists at `output_csv`
- Patient name in CSV matches `patient_name` from current_run.yaml (case-insensitive)
- Gender is `male` or `female` (not `pria`, `wanita`, or blank)
- Fields populated count ≥ `expected_fields_populated`
- Zone coverage count = `expected_zone_coverage`
- Warnings count ≤ `max_allowed_warnings`
- Permanent gap fields (`permanent_gaps`) are present in CSV header but empty — this is expected, not a fault

If CSV verification fails: record issue, continue to Step 2 but flag FAIL in report.

### Step 2 — Run JSON exporter

```
[python_exe] [json_exporter] --csv [output_csv] --out [output_json] --run-id [run_id]
```

Capture full console output to: `logs_dir/[run_id]_step2_json.log`

Verify JSON output:
- File exists at `output_json`
- File is valid JSON (parse without error)
- `patient` block: all four keys present — `name`, `age`, `gender`, `testdate`
- `patient.name` matches `patient_name` from current_run.yaml
- `patient.age` is a positive integer
- `patient.gender` is `male` or `female`
- `values` block: raw field count ≥ `expected_fields_populated`
- `values` block: zone field count ≥ `expected_zone_coverage`
- `meta` block: `source`, `version`, `run_id`, `generated_at` all present
- `meta.run_id` matches `run_id` from current_run.yaml
- `warnings` is a list (may be empty)

### Step 3 — Write operator report

Save to `operator_report` path from current_run.yaml.

Required sections:

```
# Operator Report
run_id: [run_id]
run_date: [today]
patient_name: [patient_name]
operator_status: PASS | FAIL

## Files Verified
- [list each required file with EXISTS / MISSING]

## Step 1 — CSV Exporter
result: PASS | FAIL
fields_populated: [count] / 64
zone_coverage: [count] / 60
warnings_count: [count]
issues: [list any issues found, empty if none]

## Step 2 — JSON Exporter
result: PASS | FAIL
raw_fields_in_payload: [count]
zone_fields_in_payload: [count]
meta_run_id_matches: yes | no
issues: [list any issues found, empty if none]

## Warnings (from CSV/JSON)
[list each warning verbatim, or "none"]

## Summary
[overall PASS/FAIL and brief statement of what was done]
```

### Step 4 — Update CHANGELOG.md

Read the existing CHANGELOG.md at project root before appending. Never overwrite.

Append one row per significant action:

```
| [TODAY'S DATE] | [what changed — be specific] | [affected files] | done |
```

Example entries:
```
| 2026-11-01 | Processed QRMA_Ridwan_November_21.pdf — 60/64 fields, 60/60 zones | ridwan_2025-11-10.csv, ridwan_2025-11-10.json | done |
| 2026-11-01 | CSV step PASS — JSON step FAIL: invalid zone label in tx-pb_zone | ridwan_2025-11-10.csv | pending-update |
```

Set STATUS to `done` for completed actions, `pending-update` for items needing follow-up.
