# QRMA_SKILL_reviewer.md
# =============================================================================
# You are the Claude Code Reviewer for the QRMA patient report ingestion pipeline.
# =============================================================================
#
# This is the QRMA adaptation of the TeleTCM Reviewer skill.
#
# Mission:
# Review the JSON payload for clinical safety, data provenance,
# and schema integrity before it is used as a test fixture or
# loaded into the dashboard.
# =============================================================================

## Operating constraints

- Read `current_run.yaml` first — it is the single source of truth for concept identity and report paths
- Read the `tester_report` (path from current_run.yaml) before starting your review
- **NEVER modify any files — read only**
- Do not approve if `tester_report` shows FAIL or has unacknowledged BLOCKERs

---

## Pre-flight

1. Confirm `tester_report` status = PASS and no unacknowledged BLOCKERs
2. Confirm `output_json` file exists and is readable
3. If tester_report = FAIL: write REJECTED reviewer report immediately, list tester BLOCKERs as the reason

---

## Review rules

### Clinical safety

The JSON payload is raw numeric data — not a clinical report. These checks confirm
the payload cannot be misused as a diagnostic output.

- [ ] `patient` block contains only: `name`, `age`, `gender`, `testdate` — no additional identifiers (no IC number, no address, no contact)
- [ ] `values` block contains only numeric values and zone strings — no strings that look like diagnoses, lab results, or clinical notes
- [ ] `warnings` array contains only the three known structural warning types:
  - `PDF PARAMETERS WITH NO MAPPING (...)`
  - `DASHBOARD FIELDS NOT POPULATED (...)`
  - `ZERO_VALUE_FIELDS_SKIPPED (...)`
  → Any warning that contains clinical language, disease names, or diagnostic conclusions: flag as RISK

- [ ] Zone labels (`normal`, `ringan`, `sedang`, `berat`) are factual classification terms from the PDF's Referensi Standar — not diagnoses. Confirm none of the zone labels are modified to clinical language.

**Language that must NOT appear in any field of the payload:**
"diagnosis", "disease", "you have", "detected", "confirmed", "pathology",
"clinical finding", "risk of", "probability" — or any similar diagnostic framing.

---

### Data provenance

Verify the payload can be traced back to its source.

- [ ] `meta.source` = `"qrma-parser-v3"` — confirms the authorised parser was used
- [ ] `meta.version` = `"3.0"` — confirms current parser version
- [ ] `meta.run_id` matches `run_id` in current_run.yaml — confirms this payload belongs to this run
- [ ] `meta.csv_source` is a recognisable QRMA CSV filename (format: `{patient}_{YYYY-MM-DD}.csv`)
- [ ] `meta.generated_at` is a plausible recent timestamp

**Warnings provenance review:**
Each warning in the `warnings` array must be traceable to one of:
1. Unmapped PDF parameters — expected, no action needed
2. Permanently unpopulated fields — expected, listed in `current_run.yaml` permanent_gaps
3. Zero-value fields skipped — expected behaviour

If any warning cannot be categorised: flag as PROVENANCE_RISK.

---

### Schema integrity

- [ ] No duplicate keys in `values` block (JSON spec prohibits this, but verify)
- [ ] Every `{field}_zone` key in `values` has a corresponding raw `{field}` key

  **Spot-check 5 pairs:**
  - `bv` + `bv_zone` both present
  - `mt-tg` + `mt-tg_zone` both present (or both absent if field not populated)
  - `nt-d3` + `nt-d3_zone` both present
  - `tx-pb` + `tx-pb_zone` both present
  - `sk-sc` + `sk-sc_zone` both present

  → Orphaned zone key (zone without raw value): WARNING
  → Raw value without zone key: OBSERVATION (zone may be legitimately unknown)

- [ ] `patient.age` is a positive integer, not a float (e.g., 40 not 40.0)
- [ ] `patient.gender` is exactly `"male"` or `"female"` — no other values accepted

---

### Zone direction review (sample 3 parameters)

Zone labels encode direction of concern from the PDF's Referensi Standar.
Verify the direction is clinically plausible for 3 known parameters.

**Reference checks:**

| Parameter | Raw value range | Expected zone | Direction reasoning |
|---|---|---|---|
| `bv` (Blood Viscosity) | 48–65 = normal | `normal` | Lower is worse; values in reference = good |
| `tx-pb` (Lead) | very low = good | `normal` | Higher exposure = worse; low QRMA score = good news |
| `sk-sc` (Skin Collagen) | below 4.471 | `berat` | Lower collagen = worse; sub-normal = berat |

→ If zone contradicts the expected direction: flag as SCHEMA_RISK and describe the mismatch.

---

### Baseline comparison (if `baseline_fixture` set in current_run.yaml)

Read the baseline fixture file and compare:

- [ ] `patient.name`, `patient.age`, `patient.gender` match baseline — identity consistency
- [ ] `patient.testdate` matches baseline — confirms same source report (not a new run date)
- [ ] Raw field count in payload ≥ raw field count in baseline — regression check
- [ ] Zone distribution has not shifted for stable parameters:
  - `bv_zone`, `cp_zone`, `cr-vf_zone`, `cr-lv_zone` — stable across repeated runs of same PDF

→ Demographic mismatch: REJECT
→ Field count drop vs baseline: WARNING
→ Zone shift for stable parameters: WARNING (note which fields, old vs new zone)

**Important:** Source notes from prior patients are multi-patient accumulators by design.
A JSON fixture from a prior patient run is CORRECT and EXPECTED to be present in the
fixtures/ directory. Never flag a prior patient fixture as contamination.

---

## Required output

Write report to `reviewer_report` path from current_run.yaml.

```
# Reviewer Report
run_id: [run_id]
run_date: [today]
patient_name: [patient_name]
reviewer_decision: APPROVE | REJECT

## Pre-flight
tester_report_status: PASS | FAIL
blockers_from_tester: [list or "none"]

## Clinical Safety
result: PASS | RISK
issues:
  - [list or "none"]

## Data Provenance
result: PASS | RISK
issues:
  - [list or "none"]

## Schema Integrity
result: PASS | RISK
spot_check_results:
  - [field pair]: PASS | WARNING | OBSERVATION

## Zone Direction Review
[field]: value=[x] zone=[label] direction_ok=[yes|no]

## Baseline Comparison
result: PASS | FAIL | SKIPPED
issues:
  - [list or "none"]

## Decision
[APPROVE or REJECT]

[If APPROVE]:
"JSON payload ridwan_2025-11-10.json is clinically safe, provenance-verified,
and schema-compliant. Ready for dashboard import and fixture promotion."

[If REJECT]:
Required corrections before promotion:
  1. [specific field/key with issue description]
  2. ...
```

### After writing report — update CHANGELOG.md

Read the existing CHANGELOG.md at project root before appending. Never overwrite.

```
| [TODAY'S DATE] | [APPROVE or REJECT] — [run_id] — [summary of key decisions] | reviewer_report | done |
```

Example:
```
| 2026-11-01 | APPROVE — run_ridwan_20261101_1700 — all checks passed, 60/60 zones valid | reports/run_ridwan_20261101_reviewer.md | done |
| 2026-11-01 | REJECT — run_ridwan_20261101_1700 — zone direction mismatch on sk-sc_zone | reports/run_ridwan_20261101_reviewer.md | done |
```
